<template>

</template>

<script>
const repathurl='http://192.168.0.46:8777/'
  const pathurl='http://localhost:8082/#/'
    export default {
        name: "Global",
       pathurl,
      repathurl,
    }
</script>

<style scoped>

</style>
