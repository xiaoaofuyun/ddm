<template>

</template>

<script>
    export default {
        name: "dlist"
    }
</script>

<style scoped>

</style>
