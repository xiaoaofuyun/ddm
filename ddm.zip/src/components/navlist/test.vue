<template>
  <div class="accept-container">

  </div>
</template>
<script>
  export default {
    name: 'test',
    data () {
      return {


      }
    },
    mounted(){

    },
    methods:{

    }
  }
</script>
<style scoped>
</style>
