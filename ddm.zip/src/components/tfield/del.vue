<template>
<div>aaaaaaaaaaaaaaa</div>
</template>

<script>
    export default {
        name: "del"
    }
</script>

<style scoped>

</style>
