<template>
  <div>

      1111111111111111
  </div>
</template>

<script>
    export default {
        name: "dtype"
    }
</script>

<style scoped>

</style>
